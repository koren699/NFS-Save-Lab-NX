# NFS Save Lab NX v0.16 — Full HD Edition

**Nintendo Switch homebrew save editor for Most Wanted (2005), Underground 2, and Carbon.** All supported functions have been successfully tested on real hardware.

**Download:** In the **Assets** section, select `nfs_save_lab_nx.nro` or `NFS_Save_Lab_NX_v0.16_Full_HD.zip`. Do not use GitHub's automatically generated "Source code" archives.

## Screenshots · Скриншоти · Скриншоты

![NFS Save Lab NX main menu — all three Need for Speed games](https://raw.githubusercontent.com/koren699/NFS-Save-Lab-NX/main/docs/screenshots/01-main-menu.jpg)

<details>
<summary>More screenshots / Інші скриншоти / Другие скриншоты</summary>

**Most Wanted — Save browser**

![Most Wanted saves](https://raw.githubusercontent.com/koren699/NFS-Save-Lab-NX/main/docs/screenshots/02-most-wanted-save-list.jpg)

**Underground 2 — Career selection**

![Underground 2 profiles](https://raw.githubusercontent.com/koren699/NFS-Save-Lab-NX/main/docs/screenshots/03-underground-2-profiles.jpg)

**Carbon — Cash editor and verified Xbox signatures**

![Carbon cash editor](https://raw.githubusercontent.com/koren699/NFS-Save-Lab-NX/main/docs/screenshots/04-carbon-cash.jpg)

</details>

## 🇺🇦 Українська

**NFS Save Lab NX** — неофіційна homebrew-програма для редагування збережень фанатських портів Need for Speed для Nintendo Switch.

- **Most Wanted (2005):** редагування грошей (**Cash**) та накопиченого рейтингу поліції (**Bounty**), з урахуванням проданих і наявних автомобілів.
- **Underground 2:** редагування грошей (**Cash**).
- **Carbon:** редагування грошей (**Cash**).
- **Безпека:** автоматична перевірка сумісності й контрольних підписів сейвів, резервне копіювання `.nfslab.bakN` перед записом та повторна перевірка.
- **Оформлення:** піксельні HD-постери трьох ігор і власна іконка Homebrew Menu в одному `.nro`.

**Встановлення:** закрийте гру; зробіть незалежну резервну копію всієї папки збережень; скопіюйте `nfs_save_lab_nx.nro` у `sdmc:/switch/` і запустіть через Homebrew Menu. Виберіть гру, змініть суму та підтвердьте запис комбінацією **ZL + ZR + A**. Усі функції перевірені на реальній Nintendo Switch.

## 🇬🇧 English

**NFS Save Lab NX** is an unofficial Nintendo Switch homebrew save editor for the community ports of Need for Speed.

- **Most Wanted (2005):** edit **Cash** and accumulated police **Bounty**, including sold and active cars.
- **Underground 2:** edit **Cash**.
- **Carbon:** edit **Cash**.
- **Safety:** automatically detect supported careers; validate checksums/signatures; create verified `.nfslab.bakN` backups before editing.
- **Design:** three HD pixel-art posters and a custom Homebrew Menu icon embedded in one `.nro`.

**Installation:** close the game completely and back up the whole save folder separately; copy `nfs_save_lab_nx.nro` to `sdmc:/switch/` and open Homebrew Menu. Choose the game, enter the desired amount, then confirm with **ZL + ZR + A**. All features have been tested in-game on a real Nintendo Switch.

## 🇷🇺 Русский

**NFS Save Lab NX** — неофициальный homebrew-редактор сохранений фанатских портов Need for Speed для Nintendo Switch.

- **Most Wanted (2005):** изменение денег (**Cash**) и накопленного рейтинга полиции (**Bounty**) с учётом активных и проданных автомобилей.
- **Underground 2:** изменение денег (**Cash**).
- **Carbon:** изменение денег (**Cash**).
- **Безопасность:** автоматический поиск подходящих файлов карьеры, проверка подписей и резервные копии `.nfslab.bakN` перед записью.
- **Оформление:** три HD-постера в пиксельном стиле и собственная иконка Homebrew Menu в одном `.nro`.

**Установка:** полностью закройте игру, сделайте независимую копию всей папки сохранений, скопируйте `nfs_save_lab_nx.nro` в `sdmc:/switch/` и запустите Homebrew Menu. Выберите игру, укажите нужную сумму, подтвердите **ZL + ZR + A**. Все функции протестированы в игре на Nintendo Switch.

---

*Unofficial fan project. Not affiliated with Electronic Arts or Nintendo. Works with specific fan-made Switch ports, not PC game saves. Keep backups. / Неофіційний фанатський проєкт, не пов'язаний з EA чи Nintendo. / Неофициальный фанатский проект, не связанный с EA или Nintendo.*
