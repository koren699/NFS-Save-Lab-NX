# NFS Save Lab NX v0.16 — Як опублікувати GitHub Release

У GitHub уже готові описи трьома мовами, галерея Markdown і GitHub Actions "Publish Full HD Release". Нижче потрібно всього три кроки. **ZIP-комплект потрібно розпакувати перед завантаженням на GitHub.**

1. **Завантажити чотири скріншоти в репозиторій:** відкрийте https://github.com/koren699/NFS-Save-Lab-NX/upload/main/docs/screenshots . Виберіть усі ЧОТИРИ з папки `01_Upload_to_docs_screenshots` і натисніть **Commit changes** (збережіть у гілку main). Потрібні саме назви `01-main-menu.jpg`, `02-most-wanted-save-list.jpg`, `03-underground-2-profiles.jpg`, `04-carbon-cash.jpg`.

2. **Завантажити готову програму в репозиторій:** відкрийте https://github.com/koren699/NFS-Save-Lab-NX/upload/main/release-assets/v0.16 . Виберіть **ОДИН** файл `nfs_save_lab_nx.nro` з папки `02_Upload_to_release-assets_v0.16` і натисніть **Commit changes** у main. Інші файли сюди не потрібні. Він уже має HD-постери та піксельну іконку.

3. **Опублікувати реліз автоматично:** відкрийте https://github.com/koren699/NFS-Save-Lab-NX/actions/workflows/publish-release.yml , оберіть **Run workflow**, гілку **main**, версію **v0.16**, потім кнопку **Run workflow**. Дочекайтеся зеленого статусу **Success**.

Після цього публічне постійне посилання:
https://github.com/koren699/NFS-Save-Lab-NX/releases/latest

Автоматизація створить реліз із тримовним описом, усіма чотирма скріншотами, повним `.nro` і ZIP. Редагувати реліз руками не потрібно.

Якщо кнопка Run workflow відсутня на телефоні, відкрийте сторінку через Safari та натисніть «Запитати настільний вебсайт» або використайте комп'ютер. Переконайтесь, що ви ввійшли у свій GitHub-акаунт.

Якщо GitHub Actions показує FAILED, відкрийте запуск, натисніть на червону задачу та скопіюйте сюди текст помилки. Не публікуйте сирий NRO з Actions: у ньому може не бути HD-постерів.
